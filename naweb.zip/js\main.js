import { config } from "./config.js";
import { defaults, LOCAL_CARD_IMAGES } from "./defaults.js";
import { db, collection, getDocs, doc, setDoc, increment } from "./firebase.js";
import { createRotator } from "./rotator.js";
import { guardarPedido } from "./pedidos.js";
import { initChatbot } from "./chatbot.js";

const state = { ...defaults, configuracoes: { ...defaults.configuracoes, whatsapp: config.WHATSAPP, email: config.EMAIL, telefone: config.TELEFONE, intervaloMs: config.INTERVALO_MS } };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
async function loadRemote() {
  if (!db) return;
  try { const settings = await getDocs(collection(db, "configuracoes")); settings.forEach((item) => { if (item.id === "site") state.configuracoes = { ...state.configuracoes, ...item.data(), email: config.EMAIL }; }); } catch (_) {}
  try {
    const plans = (await getDocs(collection(db, "planos"))).docs.map((item) => ({ id: item.id, ...item.data() })).filter((item) => typeof item.nome === "string" && item.nome.trim() && Number.isFinite(Number(item.preco)) && Array.isArray(item.funcionalidades) && item.funcionalidades.some((feature) => typeof feature === "string" && feature.trim()));
    if (plans.length) state.planos = plans.sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  } catch (_) {}
  try {
    const examples = (await getDocs(collection(db, "exemplos"))).docs.map((item) => ({ id: item.id, ...item.data() })).filter((item) => typeof item.titulo === "string" && item.titulo.trim() && ["barbearia", "restaurante", "salao", "dentista", "pet", "cafe", "ginasio", "confeitaria", "floricultura"].includes(item.categoria) && typeof item.demoUrl === "string" && item.demoUrl.trim());
    if (examples.length) {
      const additions = defaults.exemplos.filter((item) => ["dentista", "pet", "cafe", "ginasio", "confeitaria", "floricultura"].includes(item.id) && !examples.some((remote) => remote.id === item.id));
      state.exemplos = [...examples, ...additions].sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
    }
  } catch (_) {}
  try {
    const questions = (await getDocs(collection(db, "faq"))).docs.map((item) => ({ id: item.id, ...item.data() })).filter((item) => typeof item.pergunta === "string" && item.pergunta.trim() && typeof item.resposta === "string" && item.resposta.trim());
    if (questions.length) state.faq = questions.sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  } catch (_) {}
}
function contactLinks() {
  const wa = `https://wa.me/${state.configuracoes.whatsapp}`;
  $$("[data-whatsapp]").forEach((link) => { link.href = wa; }); $$("[data-email]").forEach((link) => { const email = state.configuracoes.email; link.href = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email)}&su=${encodeURIComponent("Pedido de orçamento NaWeb")}`; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = email; }); $$("[data-phone]").forEach((link) => { link.href = `tel:${state.configuracoes.telefone.replace(/\s/g, "")}`; link.textContent = state.configuracoes.telefone; });
  $$("[data-social]").forEach((link) => { const value = state.configuracoes[link.dataset.social]; if (value) link.href = value; else link.remove(); });
}
async function trackVisit() {
  try {
    if (sessionStorage.getItem("nawebVisitCounted")) return;
    sessionStorage.setItem("nawebVisitCounted", "1");
    if (!db) return;
    const dia = new Date().toLocaleDateString("sv-SE", { timeZone: "Europe/Lisbon" });
    const device = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 768 ? "mobile" : "desktop";
    await setDoc(doc(db, "estatisticas_diarias", dia), {
      dia,
      visitas: increment(1),
      [device]: increment(1)
    }, { merge: true });
    await setDoc(doc(db, "estatisticas", "visitas"), { total: increment(1) }, { merge: true });
  } catch (_) {}
}
function renderExamples(filter = "todos") {
  const root = $("#examples-grid");
  if (!root) return;
  let items = state.exemplos.filter((item) => item.ativo !== false && (filter === "todos" || item.categoria === filter));
  if (!items.length) items = defaults.exemplos.filter((item) => filter === "todos" || item.categoria === filter);
  root.innerHTML = items.map((item) => {
    const defaultExample = defaults.exemplos.find((example) => example.id === item.id || example.categoria === item.categoria);
    const localImage = Object.hasOwn(LOCAL_CARD_IMAGES, item.id) ? LOCAL_CARD_IMAGES[item.id] : null;
    const image = localImage?.src || item.imagem || item.imagemUrl || defaultExample?.imagem;
    const fallbackHandler = localImage?.fallback
      ? ` onerror="this.onerror=null;this.src='${escapeHtml(localImage.fallback)}'"`
      : "";
    const visual = image ? `<img src="${escapeHtml(image)}" alt="" loading="lazy"${fallbackHandler}>` : (item.categoria === "barbearia" ? "✂" : item.categoria === "restaurante" ? "◌" : "✿");
    return `<article class="card example-card reveal is-visible"><div class="example-visual"${image ? "" : " aria-hidden=\"true\""}>${visual}</div><h3>${escapeHtml(item.titulo)}</h3><p>${escapeHtml(item.descricao)}</p><div class="chips">${(item.tags || []).map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join("")}</div><a class="btn btn-secondary btn-small" href="${escapeHtml(item.demoUrl)}">Ver demo</a></article>`;
  }).join("");
}
const formatEuro = (value) => new Intl.NumberFormat("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(value) || 0);
function renderPlans() { const root = $("#plans-grid"); if (!root) return; let plans = state.planos.filter((item) => item.ativo !== false); if (!plans.length) plans = defaults.planos; root.innerHTML = plans.map((plan) => { const defaultPlan = defaults.planos.find((item) => item.id === plan.id || item.nome === plan.nome); const precoCriacao = plan.precoCriacao ?? defaultPlan?.precoCriacao; const features = (plan.funcionalidades || []).map((feature) => defaultPlan && /^\d+ alterações por mês$/i.test(feature) ? `${defaultPlan.alteracoesPorMes} alterações por mês` : feature); return `<article class="card plan-card ${plan.destaque ? "featured" : ""}">${plan.destaque ? '<span class="badge">Mais popular</span>' : ""}<h3>${escapeHtml(plan.nome)}</h3><p>${escapeHtml(plan.descricao)}</p>${precoCriacao ? `<div class="plan-setup">Criação do site: <strong>${formatEuro(precoCriacao)}€</strong></div>` : ""}<div class="plan-price">${formatEuro(plan.preco)}€<small>/${escapeHtml(plan.periodo)}</small></div><ul>${features.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul><button class="btn ${plan.destaque ? "btn-primary" : "btn-secondary"} choose-plan" data-plan="${escapeHtml(plan.nome)}">Escolher plano</button></article>`; }).join(""); $$(".choose-plan").forEach((button) => button.addEventListener("click", () => { $("#plano").value = button.dataset.plan; $("#contacto").scrollIntoView({ behavior: "smooth" }); })); }
function renderFaq() { const root = $("#faq-list"); if (!root) return; let items = state.faq.filter((item) => item.ativo !== false); if (!items.length) items = defaults.faq; root.innerHTML = items.map((item) => `<div class="faq-item"><button aria-expanded="false">${escapeHtml(item.pergunta)}<span>+</span></button><div class="faq-answer"><p>${escapeHtml(item.resposta)}</p></div></div>`).join(""); $$(".faq-item button").forEach((button) => button.addEventListener("click", () => { const open = button.parentElement.classList.toggle("is-open"); button.setAttribute("aria-expanded", String(open)); button.querySelector("span").textContent = open ? "−" : "+"; })); }
function setupForm() { const form = $("#contact-form"); if (!form) return; form.addEventListener("submit", async (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(form)); const error = $("#form-error"); if (data.website) return; if (!data.nome || !data.email || !data.mensagem || !data.rgpd) { error.textContent = "Preenche os campos obrigatórios e aceita a política de privacidade."; return; } let cooldown = 0; try { cooldown = Number(localStorage.getItem("nawebCooldown") || 0); } catch (storageError) { console.warn("Não foi possível ler o intervalo de envio:", storageError); } if (Date.now() < cooldown) { error.textContent = "Já recebemos uma mensagem. Podes voltar a enviar dentro de 60 segundos."; return; } const button = $("button[type=submit]", form); button.disabled = true; button.textContent = "A enviar…"; try { await guardarPedido({ nome: data.nome, email: data.email, telefone: data.telefone, tipoNegocio: data.tipoNegocio, plano: data.plano, mensagem: data.mensagem }); fetch("/api/notificar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome: data.nome, plano: data.plano, tipoNegocio: data.tipoNegocio, teste: false }) }).catch(() => {}); try { localStorage.setItem("nawebCooldown", String(Date.now() + 60000)); } catch (storageError) { console.warn("Não foi possível guardar o intervalo de envio:", storageError); } $("#contact-form-wrap").innerHTML = `<div class="confirmation"><h3>Obrigado pela tua mensagem.</h3><p>Recebemos o teu pedido. Para acelerar a resposta, podes falar connosco no WhatsApp.</p><a class="btn btn-primary" target="_blank" rel="noopener" href="https://wa.me/${state.configuracoes.whatsapp}?text=${encodeURIComponent(`Olá! Sou ${data.nome}. Tenho um negócio de ${data.tipoNegocio} e tenho interesse no plano ${data.plano}.`)}">Continuar no WhatsApp</a></div>`; } catch (submissionError) { button.disabled = false; button.textContent = "Enviar pedido"; const message = submissionError.code === "permission-denied" ? "O Firebase bloqueou este pedido. Publica as regras do ficheiro firestore.rules no teu projeto Firebase." : submissionError.code === "failed-precondition" ? "O Firestore ainda não foi ativado neste projeto Firebase." : "Não foi possível guardar agora."; error.textContent = `${message} Se precisares, contacta-nos pelo WhatsApp.`; console.error("Erro ao guardar pedido:", submissionError); } }); }
function setupNav() { const toggle = $(".menu-toggle"); const nav = $(".nav"); toggle?.addEventListener("click", () => { const open = nav.classList.toggle("is-open"); toggle.setAttribute("aria-expanded", String(open)); }); $$(".nav a").forEach((link) => link.addEventListener("click", () => { nav.classList.remove("is-open"); toggle?.setAttribute("aria-expanded", "false"); })); const sections = $$('main section[id]'); const links = $$(".nav a[href^='#']"); const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) links.forEach((link) => link.classList.toggle("active", link.hash === `#${entry.target.id}`)); }), { rootMargin: "-35% 0px -55%" }); sections.forEach((section) => observer.observe(section)); }
function setupExtras() {
  const cookie = $("#cookie");
  const consent = window.nawebCookieConsent;
  if (consent?.isAccepted()) {
    document.documentElement.classList.remove("naweb-cookie-pending");
    cookie?.remove();
  } else {
    document.documentElement.classList.add("naweb-cookie-pending");
    $("#accept-cookies")?.addEventListener("click", () => {
      consent?.accept();
      document.documentElement.classList.remove("naweb-cookie-pending");
      cookie?.remove();
    });
  }
  const notice = $("#notice-bar");
  setTimeout(() => { if (!sessionStorage.getItem("nawebNotice")) notice?.classList.add("is-visible"); }, 2000);
  $("#close-notice")?.addEventListener("click", () => { sessionStorage.setItem("nawebNotice", "1"); notice.classList.remove("is-visible"); });
  $("#top-button")?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  const observer = new IntersectionObserver((entries) => entries.forEach((entry) => entry.target.classList.toggle("is-visible", entry.isIntersecting)));
  $$(".reveal").forEach((element) => observer.observe(element));
}
async function init() { setupExtras(); await loadRemote(); initChatbot(state); trackVisit(); contactLinks(); createRotator($("#hero-rotator"), state.configuracoes.mensagensHero, state.configuracoes.intervaloMs); createRotator($("#bar-rotator"), state.configuracoes.mensagensBarra, state.configuracoes.intervaloMs); renderExamples(); renderPlans(); renderFaq(); setupNav(); setupForm(); $$(".filter").forEach((button) => button.addEventListener("click", () => { $$(".filter").forEach((item) => item.classList.remove("is-active")); button.classList.add("is-active"); renderExamples(button.dataset.filter); })); $("#year").textContent = new Date().getFullYear(); }
init();
